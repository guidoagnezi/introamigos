import pygame
from enum import Enum
import tkinter as tk
from tkinter.filedialog import askopenfilename

root = tk.Tk()
root.withdraw()

LARGURA = 1024
ALTURA = 768
FPS = 60
TITULO = "Intro Amigos"

# Constantes Amigos
# Estados


WANDERING = "wandering"
FOLLOWING = "following"
HUNGRY = "hungry"
EATING = "eating"
TALKING = "talking"
PERSUING = "persuing"
STEALING = "stealing"

# Temporizadores

WANDER_TIME = 120

# Velocidade e Posicao

SPAWN_LIMIT = 200
MAX_VEL_X = 2
MAX_VEL_Y = 2

img_seta = pygame.image.load("amigo/seta.png")

pygame.font.init()
fonte = pygame.font.SysFont(None, 24)
fonte2 = pygame.font.Font("fonte/guidofontenasal.ttf", 26)
fonte3 = pygame.font.Font("fonte/guidofontenasal.ttf", 30)
fonte4 = pygame.font.Font("fonte/guidofontenasal.ttf", 20)